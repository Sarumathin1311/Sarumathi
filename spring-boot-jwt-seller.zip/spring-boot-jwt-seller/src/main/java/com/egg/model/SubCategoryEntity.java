/*SubCategory Entity Class*/
package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SubCategoryEntity 
{
	@Id	
	private int subcategoryId;
	private String subcategoryName;
	private String subbreifDetails;
	private String gstPercent;
	
	@ManyToOne
	@JoinColumn(name="categoryId")
    private CategoryEntity category_Id;

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getSubcategoryName() {
		return subcategoryName;
	}

	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}

	public String getSubbreifDetails() {
		return subbreifDetails;
	}

	public void setSubbreifDetails(String subbreifDetails) {
		this.subbreifDetails = subbreifDetails;
	}

	public String getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(String gstPercent) {
		this.gstPercent = gstPercent;
	}

	/*public CategoryEntity getParent() {
		return parent;
	}

	public void setParent(CategoryEntity parent) {
		this.parent = parent;
	}

	public SubCategoryEntity() {
		// TODO Auto-generated constructor stub
	}*/

	public SubCategoryEntity(int subcategoryId, String subcategoryName, String subbreifDetails, String gstPercent
			) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.subbreifDetails = subbreifDetails;
		this.gstPercent = gstPercent;
		
	}

	public SubCategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", subbreifDetails=" + subbreifDetails + ", gstPercent=" + gstPercent + "]";
	}

	
	
	
	
	

}
