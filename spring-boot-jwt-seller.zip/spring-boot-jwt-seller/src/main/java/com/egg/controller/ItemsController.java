package com.egg.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ItemsEntity;
import com.egg.service.impl.ItemsService;



@RestController
@RequestMapping("/items")
@CrossOrigin(origins="*")
public class ItemsController {
	
	@Autowired
	private ItemsService itemsService;
	
	@GetMapping(value = "/{sid}/getAll")
	public List<ItemsEntity> getAllItems(@PathVariable("sid")Integer sellerId) {
	return itemsService.getAllItems(sellerId);
	
	}

	
	@PostMapping(value="/{sid}/add",produces = "application/json")
	public ItemsEntity addItem(@PathVariable("sid") Integer sellerId,@RequestBody ItemsEntity Item) {
		Optional<ItemsEntity> savedItem = itemsService.addItem(Item, sellerId);
		return savedItem.get();
	}
	@DeleteMapping(value = "/{itemid}/deletebyid",produces="application/json")
	public String deleteItemById(@PathVariable("itemid") Integer itemId) {
		return itemsService.deleteItemById(itemId);
	}
	
	@DeleteMapping(value = "/{sid}/deleteall")
	public void deleteall(@PathVariable("sid") Integer sellerId) {
		itemsService.deleteall(sellerId);
	}
	

	@PutMapping(value = "/{itemid}/update",produces = "application/json")
	public ItemsEntity updateItem(@RequestBody ItemsEntity Item,@PathVariable("itemid") Integer Id) {
		return itemsService.updateItem(Item, Id);
	}
	
	@GetMapping(value = "/searchbyname/{itemname}")
	public List<ItemsEntity>searchItem( @PathVariable("itemname") String itemname)
	{
		return itemsService.getitembyname(itemname);
	}
	

	@PutMapping(value = "/updateStock/{id}")
	public ItemsEntity updateStock(@RequestBody ItemsEntity Item, @PathVariable("id") Integer Id)
	{
		return itemsService.updateStocknumbers(Item, Id);
	}
		
}

