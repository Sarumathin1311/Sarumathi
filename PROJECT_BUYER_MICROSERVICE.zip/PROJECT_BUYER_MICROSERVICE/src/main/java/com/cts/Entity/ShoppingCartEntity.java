
package com.cts.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "shoppingcart")
public class ShoppingCartEntity  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int CartId;
	private int itemId;
	private int itemQuantity;
	private int itemPrice;
	private String itemName;
	private String itemDescription;

	
	@ManyToOne
	@JoinColumn(name="buyerId")
	private BuyerEntity buyerId;

	public ShoppingCartEntity() {
		
		// TODO Auto-generated constructor stub
	}

	public int getCartId() {
		return CartId;
	}

	public void setCartId(int cartId) {
		CartId = cartId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public BuyerEntity getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(BuyerEntity buyerId) {
		this.buyerId = buyerId;
	}

	public ShoppingCartEntity(int cartId, int itemId, int itemQuantity, int itemPrice, String itemName,
			String itemDescription, BuyerEntity buyerId) {
		super();
		CartId = cartId;
		this.itemId = itemId;
		this.itemQuantity = itemQuantity;
		this.itemPrice = itemPrice;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.buyerId = buyerId;
	}

	@Override
	public String toString() {
		return "ShoppingCartEntity [CartId=" + CartId + ", itemId=" + itemId + ", itemQuantity=" + itemQuantity
				+ ", itemPrice=" + itemPrice + ", itemName=" + itemName + ", itemDescription=" + itemDescription
				+ ", buyerId=" + buyerId + "]";
	}

	
	
	

}
