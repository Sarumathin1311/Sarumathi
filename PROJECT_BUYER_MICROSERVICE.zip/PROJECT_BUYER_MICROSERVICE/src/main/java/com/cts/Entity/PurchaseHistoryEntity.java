/*Purchase History Entity Class*/
package com.cts.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class PurchaseHistoryEntity {
	
	@Id
	@GeneratedValue
	private int purchasehisId;
	
	private int numberofItems;
	private String itemName;
	private int itemPrice;

	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private BuyerEntity buyerEntity;


	public PurchaseHistoryEntity() {
		
		// TODO Auto-generated constructor stub
	}


	public int getPurchasehisId() {
		return purchasehisId;
	}


	public void setPurchasehisId(int purchasehisId) {
		this.purchasehisId = purchasehisId;
	}


	public int getNumberofItems() {
		return numberofItems;
	}


	public void setNumberofItems(int numberofItems) {
		this.numberofItems = numberofItems;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public int getItemPrice() {
		return itemPrice;
	}


	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}


	public BuyerEntity getBuyerEntity() {
		return buyerEntity;
	}


	public void setBuyerEntity(BuyerEntity buyerEntity) {
		this.buyerEntity = buyerEntity;
	}


	public PurchaseHistoryEntity(int purchasehisId, int numberofItems, String itemName, int itemPrice,
			BuyerEntity buyerEntity) {
		super();
		this.purchasehisId = purchasehisId;
		this.numberofItems = numberofItems;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.buyerEntity = buyerEntity;
	}


	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchasehisId=" + purchasehisId + ", numberofItems=" + numberofItems
				+ ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", buyerEntity=" + buyerEntity + "]";
	}


		}


	
	
	
	/*@ManyToOne
	@JoinColumn(name="sellerId")
    private SellerEntity sellerEntity;
	
	@ManyToOne
	@JoinColumn(name="transactionId")
    private TransactionEntity transactionEntity;
	
	@ManyToOne
	@JoinColumn(name="itemId")
    private ItemsEntity itemEntity;*/


	
	


	


	
	
	


	

	


	
	
	
	
	
	


