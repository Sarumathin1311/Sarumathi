package com.cts.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Entity.TransactionEntity;
import com.cts.Service.TransactionService;



@RestController
@RequestMapping("/transaction")
@CrossOrigin(origins="*")
public class TransactionController {
	
	

	@Autowired
	private TransactionService transactionService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<TransactionEntity> getAllTransactionItems(@PathVariable("bid")Integer buyerId) {
		return transactionService.getAllTransactionItems(buyerId);}
}

