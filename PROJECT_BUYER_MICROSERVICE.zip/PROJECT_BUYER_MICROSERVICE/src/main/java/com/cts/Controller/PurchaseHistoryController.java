package com.cts.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Entity.PurchaseHistoryEntity;

import com.cts.Service.PurchaseHistoryService;

@RestController
@RequestMapping("/purchase")
@CrossOrigin(origins="*")
public class PurchaseHistoryController {
	
	@Autowired
	private PurchaseHistoryService purchasehistoryService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<PurchaseHistoryEntity> getAllPurchaseItems(@PathVariable("bid")Integer buyerId) {
	return purchasehistoryService.getAllPurchaseItems(buyerId);
	
	}
}

