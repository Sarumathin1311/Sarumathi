package com.cts.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Dao.TransactionDao;
import com.cts.Entity.TransactionEntity;


@Service
public class TransactionService {

	
	@Autowired
	private TransactionDao transactionDao;
	
	public List<TransactionEntity> getAllTransactionItems(Integer buyerId){
		return transactionDao.getallTransactionitems(buyerId);
	}
}
