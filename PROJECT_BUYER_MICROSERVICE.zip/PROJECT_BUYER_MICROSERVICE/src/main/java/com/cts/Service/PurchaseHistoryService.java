package com.cts.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Dao.PurchaseDao;
import com.cts.Dao.ShoppingCartDao;
import com.cts.Dao.TransactionDao;
import com.cts.Entity.PurchaseHistoryEntity;
import com.cts.Entity.ShoppingCartEntity;
import com.cts.Entity.TransactionEntity;

@Service
public class PurchaseHistoryService {

	
	

	@Autowired
	private  PurchaseDao purchaseDao;
	
	
	
	
	public List<PurchaseHistoryEntity> getAllPurchaseItems(Integer buyerId){
		return purchaseDao.getallPurchaseitems(buyerId);
	}
}
