
public interface notepad
{
	public abstract void display();
	public abstract void edit();

}
