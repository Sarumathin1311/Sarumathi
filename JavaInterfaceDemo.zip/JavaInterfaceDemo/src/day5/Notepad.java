package day5;

public interface Notepad 
{
		public abstract void display();
		public abstract void edit();
}


