package day5;

public class Notepad1 {

}
