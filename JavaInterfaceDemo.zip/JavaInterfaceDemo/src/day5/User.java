package day5;

public class User extends Operatingsys{
	public static void main(String args[])
	{
		Operatingsys Os=new Operatingsys();
		Os.display();
		Os.edit();
		System.out.println("User access Notepad using OS");
}
}