package com.cts.jdbc.Spring_Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class App {
	public static void main(String[] args) throws ClassNotFoundException {
		
		ResultSet rs =null;
		Statement st=null;
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		final String DB_URL = "jdbc:mysql://localhost/project";
		final String UN = "root";
		final String PASS = "pass";
		Connection conn = null;
		Class b = Class.forName(JDBC_DRIVER);
	
		try {
			conn = DriverManager.getConnection(DB_URL, UN, PASS);
			st = conn.createStatement();
			rs= st.executeQuery("select * from Product");

			while (rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getString(4));
			}
		
		} catch (Exception e) {
			System.out.println("in excep");
		}
		finally{
			try {
				System.out.println("in finally");
				/*rs.close();
				st.close();*/
				if(conn!=null){
					System.out.println("in finally - in if");
					conn.close();	
				}
				
			} catch (SQLException e) {
				System.out.println("...."+e.getMessage());
			}
			
		}
	}
}
