package com.cts.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Dao.BuyerDao;
import com.cts.Entity.BuyerEntity;


@Service
public class BuyerService 
{

	@Autowired
	private BuyerDao buyerdao;
	
	public List<BuyerEntity> getAllBuyerEntity()
	{
		List<BuyerEntity> buyerList=new ArrayList<>();
		return buyerList;
	}
	
	public BuyerEntity addBuyerEntity(BuyerEntity buyerEntity)
	{
		buyerEntity=buyerdao.save(buyerEntity);
		return buyerEntity;
		
	}








	   
}
