package com.cts.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Dao.ItemsDao;
import com.cts.Dao.SellerDao;
import com.cts.Entity.ItemsEntity;

@Service
public class ItemsService 
{

	@Autowired
	private ItemsDao itemsdao;
	
	@Autowired
	private SellerDao sellerDao;
	
	
	public List<ItemsEntity> getAllItemsEntity()
	{
		List<ItemsEntity> itemsList=new ArrayList<>();
		return itemsList;
	}
	public Optional<ItemsEntity> addItem(ItemsEntity CartItem, Integer sellerId) {
		return sellerDao.findById(sellerId).map(seller -> {
			CartItem.setSellerId(seller);
			return itemsdao.save(CartItem);
		});
		
	}

	   
}