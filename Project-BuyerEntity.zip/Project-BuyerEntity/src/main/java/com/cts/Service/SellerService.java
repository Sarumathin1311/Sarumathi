package com.cts.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.Dao.SellerDao;
import com.cts.Entity.SellerEntity;

@Service
public class SellerService 
{

	@Autowired
	private SellerDao sellerdao;
	
	public List<SellerEntity> getAllSellerEntity()
	{
		List<SellerEntity> sellerList=new ArrayList<>();
		return sellerList;
	}
	
	public SellerEntity addSellerEntity(SellerEntity sellerEntity)
	{
		sellerEntity=sellerdao.save(sellerEntity);
		return sellerEntity;
		
	}}