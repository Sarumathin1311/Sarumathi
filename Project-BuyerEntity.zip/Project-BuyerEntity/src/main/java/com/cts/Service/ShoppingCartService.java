package com.cts.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.Dao.BuyerDao;
import com.cts.Dao.ShoppingCartDao;
import com.cts.Entity.ShoppingCartEntity;




@Service
public class ShoppingCartService {
	
	@Autowired
	private ShoppingCartDao shoppingcartDao;
	
	@Autowired
	private BuyerDao buyerDao;
	
	
	public List<ShoppingCartEntity> getAllCartItems(Integer buyerId){
		return shoppingcartDao.getAllCartItems(buyerId);
	}
	
	public Optional<ShoppingCartEntity> addCartItem(ShoppingCartEntity shoppingCartItem, Integer buyerId) {
		return buyerDao.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyer);
			return shoppingcartDao.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer Id) {
		shoppingcartDao.deleteById(Id);
		return "Item with cartId "+Id+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
	
		shoppingcartDao.emptyCart(buyerId);
	}
	
	public ShoppingCartEntity updateCart(ShoppingCartEntity shoppingCartItem, Integer Id) {
		ShoppingCartEntity shoppingcart = null;
		Optional<ShoppingCartEntity> cartItem = shoppingcartDao.findById(Id);
		
		if(cartItem.isPresent())
		{
		shoppingcart = cartItem.get();
		shoppingcart.setItemId(shoppingCartItem.getItemId());
		shoppingcart.setItemQuantity(shoppingCartItem.getItemQuantity());
		shoppingcart.setItemDescription(shoppingCartItem.getItemDescription());
		
		return shoppingcartDao.save(shoppingcart);
		}
		return null;
		
		
		
		
	}
	

}


