
package com.cts.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "shoppingcart")
public class ShoppingCartEntity  {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Cartid;
	private float price;
	private String description;
	public int getCartid() {
		return Cartid;
	}
	@ManyToOne
	@JoinColumn(name="buyerid")
	public void setCartid(int cartid) {
		Cartid = cartid;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "ShoppingCart [Cartid=" + Cartid + ", price=" + price + ", description=" + description + "]";
	}
	
}
