/*Transaction Entity Class*/
package com.cts.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.cts.Entity.BuyerEntity;

@Entity
public class TransactionEntity {
	
	@Id
	@GeneratedValue
	private int transactionId;
	private String transactionType;
	private Date transactionDate;
	private String transactionRemarks;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private BuyerEntity buyerEntity;
	
	@ManyToOne
	@JoinColumn(name="sellerId")
    private SellerEntity sellerEntity;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionRemarks() {
		return transactionRemarks;
	}

	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}

	/*public BuyerEntity getBuyerEntity() {
		return buyerEntity;
	}

	public void setBuyerEntity(BuyerEntity buyerEntity) {
		this.buyerEntity = buyerEntity;
	}

	public SellerEntity getSellerEntity() {
		return sellerEntity;
	}

	public void setSellerEntity(SellerEntity sellerEntity) {
		this.sellerEntity = sellerEntity;
	}*/

	public TransactionEntity() {
		// TODO Auto-generated constructor stub
	}

	public TransactionEntity(int transactionId, String transactionType, Date transactionDate, String transactionRemarks
			) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.transactionRemarks = transactionRemarks;
		
	}

	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", transactionRemarks=" + transactionRemarks + "]";
	}

	
	
}
