/*Purchase History Entity Class*/
package com.cts.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class PurchaseHistoryEntity {
	
	@Id
	private int purchasehisId;
	
	private int numberofItems;
	private String remarks;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private BuyerEntity buyerEntity;
	
	
	@ManyToOne
	@JoinColumn(name="sellerId")
    private SellerEntity sellerEntity;
	
	@ManyToOne
	@JoinColumn(name="transactionId")
    private TransactionEntity transactionEntity;
	
	@ManyToOne
	@JoinColumn(name="itemId")
    private ItemsEntity itemEntity;


	public int getPurchasehisId() {
		return purchasehisId;
	}


	public void setPurchasehisId(int purchasehisId) {
		this.purchasehisId = purchasehisId;
	}


	public int getNumberofItems() {
		return numberofItems;
	}


	public void setNumberofItems(int numberofItems) {
		this.numberofItems = numberofItems;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public BuyerEntity getBuyerEntity() {
		return buyerEntity;
	}


	public void setBuyerEntity(BuyerEntity buyerEntity) {
		this.buyerEntity = buyerEntity;
	}


	


	


	public PurchaseHistoryEntity(int purchasehisId, int numberofItems, String remarks, BuyerEntity buyerEntity,
			SellerEntity sellerEntity, TransactionEntity transactionEntity, ItemsEntity itemEntity) {
		super();
		this.purchasehisId = purchasehisId;
		this.numberofItems = numberofItems;
		this.remarks = remarks;
		this.buyerEntity = buyerEntity;
		this.sellerEntity = sellerEntity;
		this.transactionEntity = transactionEntity;
		this.itemEntity = itemEntity;
	}


	public SellerEntity getSellerEntity() {
		return sellerEntity;
	}


	public void setSellerEntity(SellerEntity sellerEntity) {
		this.sellerEntity = sellerEntity;
	}


	public TransactionEntity getTransactionEntity() {
		return transactionEntity;
	}


	public void setTransactionEntity(TransactionEntity transactionEntity) {
		this.transactionEntity = transactionEntity;
	}


	public ItemsEntity getItemEntity() {
		return itemEntity;
	}


	public void setItemEntity(ItemsEntity itemEntity) {
		this.itemEntity = itemEntity;
	}


	


	public PurchaseHistoryEntity() {
	
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchasehisId=" + purchasehisId + ", numberofItems=" + numberofItems
				+ ", remarks=" + remarks + ", buyerEntity=" + buyerEntity + ", sellerEntity=" + sellerEntity
				+ ", transactionEntity=" + transactionEntity + ", itemEntity=" + itemEntity + "]";
	}


	


	


	
	
	


	

	


	
	
	
	
	
	

}
