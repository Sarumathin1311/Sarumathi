  //*Discount Entity Class*/
package com.cts.Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DiscountsEntity {
	
	@Id
	private int discountId;
	private String discountCode;
	private int discountPercent;
	private Date startDate;
	private Date endDate;
	private String discountDescrip;
	
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public int getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(int discountPercent) {
		this.discountPercent = discountPercent;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getDiscountDescrip() {
		return discountDescrip;
	}
	public void setDiscountDescrip(String discountDescrip) {
		this.discountDescrip = discountDescrip;
	}
	
	public DiscountsEntity() {
	
		// TODO Auto-generated constructor stub
	}
	public DiscountsEntity(int discountId, String discountCode, int discountPercent, Date startDate, Date endDate,
			String discountDescrip) {
		super();
		this.discountId = discountId;
		this.discountCode = discountCode;
		this.discountPercent = discountPercent;
		this.startDate = startDate;
		this.endDate = endDate;
		this.discountDescrip = discountDescrip;
	}
	@Override
	public String toString() {
		return "DiscountsEntity [discountId=" + discountId + ", discountCode=" + discountCode + ", discountPercent="
				+ discountPercent + ", startDate=" + startDate + ", endDate=" + endDate + ", discountDescrip="
				+ discountDescrip + "]";
	}
	
	
	
	
	
	
	
}