package com.cts.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Entity.ShoppingCartEntity;
import com.cts.Service.ShoppingCartService;

@RestController
@RequestMapping("/cart")
public class ShoppingCartController {

	@Autowired
	private ShoppingCartService shoppingcartService;
	
	@GetMapping
	public List<ShoppingCartEntity> getAll()
	{
		return shoppingcartService.getAllShoppingCartEntity();
	}
	
	@PostMapping("/add")
	public ShoppingCartEntity add(@Valid @RequestBody ShoppingCartEntity shoppingcartEntity)
	{
		return shoppingcartService.addBuyerEntity(shoppingcartEntity);
	}

	  
	
	}