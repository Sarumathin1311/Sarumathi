package com.cts.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Entity.ItemsEntity;
import com.cts.Service.ItemsService;

@RestController
@RequestMapping("/items")
public class ItemsController {

	@Autowired
	private ItemsService itemsService;
	
	@GetMapping
	public List<ItemsEntity> getAll()
	{
		return itemsService.getAllItemsEntity();
	}
	
	@PostMapping("/add")
	public ItemsEntity add(@Valid @RequestBody ItemsEntity itemsEntity)
	{
		return itemsService.addItem(itemsEntity);
	}

	  
	
	}
