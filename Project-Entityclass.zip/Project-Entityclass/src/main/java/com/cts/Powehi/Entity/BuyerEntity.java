/*Buyer Entity class*/
package com.cts.Powehi.Entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class BuyerEntity {
	@Id
	private int buyerId;
	private String buyerName;
	private String buyerPass;
	private String buyerEmail;
	private String buyerMobile;
	private Date createdate;
	private Date createtime;
	
	
	@OneToMany(targetEntity=PurchaseHistoryEntity.class, cascade=CascadeType.ALL)
	private List<PurchaseHistoryEntity> purchasehistory;
	
	@OneToMany(targetEntity=ShoppingCartEntity.class, cascade=CascadeType.ALL)
	private List<ShoppingCartEntity> Shoppingcartt;
	
	
	
	

}
