/*Items Entity Class*/
package com.cts.Powehi.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ItemsEntity {
	@Id
	private int itemId;
	private int categoryId;
	private int itemPrice;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	public ItemsEntity() {
		
		// TODO Auto-generated constructor stub
	}
	
	public ItemsEntity(int itemId, int categoryId, int itemPrice, String itemName, String description, int stockNumber,
			String remarks) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.itemPrice = itemPrice;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}
	
	
	
	
}
