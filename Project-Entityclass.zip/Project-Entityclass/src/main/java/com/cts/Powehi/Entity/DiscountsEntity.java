package com.cts.Powehi.Entity;

public class DiscountsEntity {

}
