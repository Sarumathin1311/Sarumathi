package com.cts.Powehi.Entity;

public class CategoryEntity {
	
	
	private int itemId;
	private int categoryId;
	private int itemPrice;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	

	
}
