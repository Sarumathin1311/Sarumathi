/*SubCategory Entity Class*/
package com.cts.Powehi.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class SubCategoryEntity 
{
	@Id	
	private int subcategoryId;
	private String subcategoryName;
	private String subbreifDetails;
	private String gstPercent;
	
	@JoinColumn(name="categoryId", referencedColumnName="ID")
    private CategoryEntity parent;

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getSubcategoryName() {
		return subcategoryName;
	}

	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}

	public String getSubbreifDetails() {
		return subbreifDetails;
	}

	public void setSubbreifDetails(String subbreifDetails) {
		this.subbreifDetails = subbreifDetails;
	}

	public String getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(String gstPercent) {
		this.gstPercent = gstPercent;
	}

	public CategoryEntity getParent() {
		return parent;
	}

	public void setParent(CategoryEntity parent) {
		this.parent = parent;
	}

	public SubCategoryEntity() {
		// TODO Auto-generated constructor stub
	}

	public SubCategoryEntity(int subcategoryId, String subcategoryName, String subbreifDetails, String gstPercent,
			CategoryEntity parent) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.subbreifDetails = subbreifDetails;
		this.gstPercent = gstPercent;
		this.parent = parent;
	}

	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", subbreifDetails=" + subbreifDetails + ", gstPercent=" + gstPercent + ", parent=" + parent + "]";
	}
	
	
	
	

}
