package com.cts.inheritance;

public class Calculator {

	int a,b,result;
	
	public void add(int a,int b){
		int result=a+b;
		System.out.println("result of adding a + b is "+result);
	}
	public void sub(int a,int b){
		int result=a-b;
		System.out.println("subraction result is "+result);
	}	
}
