package com.cts.inheritance;

public class ScientificCalculator extends Calculator 
{
	public void sin(){
		System.out.println("sine");
	}
	public void cos(){
		System.out.println("cos");
	}
	

}
