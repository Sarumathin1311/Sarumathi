/*Employee details program using inheritance*/
package com.cts.inheritance;

public class Manager extends Employee {

	public Manager() {
		// TODO Auto-generated constructor stub
	}
	public Manager(int id,String name,String dept,String comp) {
	super(id,name,dept,comp);
	
	System.out.println("Manager");
	}
	

}
