package com.cts.inheritance;

public class TestInheritance2 {

	public static void main(String[] args) {
		Derived obj =new Derived();
		Derived obj1 =new Derived(123);
	}

}

class Base{
	int id;
	public Base() {
		System.out.println("base");
	}
	public Base(int a) {
		this.id=a;
		System.out.println("base with arg "+id);
	}
}

class Derived extends Base{
	public Derived() {
	//super(78);
	System.out.println("derived");
	}
	public Derived(int g) {
		super(g);
	System.out.println("derived with arg");
	}
	
}


