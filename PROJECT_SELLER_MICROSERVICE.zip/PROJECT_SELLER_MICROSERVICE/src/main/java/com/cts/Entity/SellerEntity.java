/*Seller Entity Class*/
package com.cts.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SellerEntity {
	
	@Id
	@GeneratedValue
	private int sellerId;
	private String sellerName;
	private String sellerPass;
	private String sellercmyName;
	//private String gstregNum;
	private String cmyDescription;
	private String sellerAddress;
	private String sellerWebsite;
	private String sellerEmail;
	private String sellerMobile;
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getSellerPass() {
		return sellerPass;
	}
	public void setSellerPass(String sellerPass) {
		this.sellerPass = sellerPass;
	}
	public String getSellercmyName() {
		return sellercmyName;
	}
	public void setSellercmyName(String sellercmyName) {
		this.sellercmyName = sellercmyName;
	}
	//public String getGstregNum() {
	//	return gstregNum;
	//}
	//public void setGstregNum(String gstregNum) {
	//	this.gstregNum = gstregNum;
	//}
	public String getCmyDescription() {
		return cmyDescription;
	}
	public void setCmyDescription(String cmyDescription) {
		this.cmyDescription = cmyDescription;
	}
	public String getSellerAddress() {
		return sellerAddress;
	}
	public void setSellerAddress(String sellerAddress) {
		this.sellerAddress = sellerAddress;
	}
	public String getSellerWebsite() {
		return sellerWebsite;
	}
	public void setSellerWebsite(String sellerWebsite) {
		this.sellerWebsite = sellerWebsite;
	}
	public String getSellerEmail() {
		return sellerEmail;
	}
	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	public String getSellerMobile() {
		return sellerMobile;
	}
	public void setSellerMobile(String sellerMobile) {
		this.sellerMobile = sellerMobile;
	}
	public SellerEntity(int sellerId, String sellerName, String sellerPass, String sellercmyName, String gstregNum,
			String cmyDescription, String sellerAddress, String sellerWebsite, String sellerEmail,
			String sellerMobile) {
		super();
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.sellerPass = sellerPass;
		this.sellercmyName = sellercmyName;
		//this.gstregNum = gstregNum;
		this.cmyDescription = cmyDescription;
		this.sellerAddress = sellerAddress;
		this.sellerWebsite = sellerWebsite;
		this.sellerEmail = sellerEmail;
		this.sellerMobile = sellerMobile;
	}
	public SellerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SellerEntity [sellerId=" + sellerId + ", sellerName=" + sellerName + ", sellerPass=" + sellerPass
				+ ", sellercmyName=" + sellercmyName + ", cmyDescription=" + cmyDescription + ", sellerAddress="
				+ sellerAddress + ", sellerWebsite=" + sellerWebsite + ", sellerEmail=" + sellerEmail
				+ ", sellerMobile=" + sellerMobile + "]";
	}
	
	
	

}
