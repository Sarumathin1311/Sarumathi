package com.cts.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.Entity.ItemsEntity;


@Repository
public interface ItemsDao extends JpaRepository<ItemsEntity, Integer>{
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM items_entity WHERE items_entity.seller_id = :sellerId",nativeQuery = true)
	public void deleteall(@Param("sellerId")Integer sellerId);
	
	

	@Query(value = "SELECT * FROM items_Entity c WHERE c.seller_id = :sellerId"
			,nativeQuery = true)
	public List<ItemsEntity> getAllItems(@Param("sellerId")Integer sellerId);
	
	
	
	
	@Query(value="from ItemsEntity where item_name like %:itemname% ")
	public List<ItemsEntity>finditem(@Param("itemname") String itemname);

}
