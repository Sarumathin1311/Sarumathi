package com.cts.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Dao.ItemsDao;
import com.cts.Dao.SellerDao;
import com.cts.Entity.ItemsEntity;


@Service
public class ItemsService 
{

	@Autowired
	private ItemsDao itemsdao;
	
	@Autowired
	private SellerDao sellerDao;
	
	public List<ItemsEntity> getAllItems(Integer sellerId){
		return itemsdao.getAllItems(sellerId);
	}
	public Optional<ItemsEntity> addItem(ItemsEntity CartItem, Integer sellerId) {
		return sellerDao.findById(sellerId).map(seller -> {
			CartItem.setSellerId(seller);
			
			return itemsdao.save(CartItem);
		});
		
	}
	


	public String deleteItemById(Integer itemId) {
		itemsdao.deleteById(itemId);
		return null;

	}
	
	public void deleteall(Integer sellerId) {
		
		itemsdao.deleteall(sellerId);
	}
	   
	public ItemsEntity updateItem(ItemsEntity Item, Integer Id) {
		ItemsEntity item = null;
		Optional<ItemsEntity> itemEntity = itemsdao.findById(Id);
		
		if(itemEntity.isPresent())
		{
		item = itemEntity.get();
		item.setItemId(Item.getItemId());
		item.setCategoryId(Item.getCategoryId());
		item.setItemPrice(Item.getItemPrice());
		item.setItemName(Item.getItemName());
		item.setDescription(Item.getDescription());
		item.setStockNumber(Item.getStockNumber());
		item.setRemarks(Item.getRemarks());
		item.setSubcategoryId(Item.getSubcategoryId());
		item.setSellerId(Item.getSellerId());
		
		
		return itemsdao.save(item);
		}
		return null;
		}
	
	
	public List<ItemsEntity> getitembyname(String itemname)
	{
		return itemsdao.finditem(itemname);
	}
	
	public ItemsEntity updateStocknumbers(ItemsEntity Item,Integer Id)
	{
		ItemsEntity item = null;
		Optional<ItemsEntity> itemEntity = itemsdao.findById(Id);
		if(itemEntity.isPresent())
		{
			item = itemEntity.get();
		item.setStockNumber(Item.getStockNumber()); 
		return itemsdao.save(item);
		}
		
		return Item;
		
	}
	
}