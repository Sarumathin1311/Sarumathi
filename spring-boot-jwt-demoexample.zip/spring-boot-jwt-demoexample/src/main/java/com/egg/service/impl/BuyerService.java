package com.egg.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.model.BuyerEntity;

@Service
public class BuyerService implements UserDetailsService
{

	@Autowired
	private BuyerDao buyerdao;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public List<BuyerEntity> getAllBuyerEntity()
	{
		return buyerdao.findAll();
	}
	
	
	public BuyerEntity addBuyerEntity (BuyerEntity buyerentity) {
		buyerentity.setBuyerPass(bcryptEncoder.encode(buyerentity.getBuyerPass()));
		return buyerdao.save(buyerentity);
	}

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerEntity buyerentity = buyerdao.findByBuyerName(username);
		if(buyerentity == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyerentity.getBuyerName(), buyerentity.getBuyerPass(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public BuyerEntity findOne(String buyerName) {
		return buyerdao.findByBuyerName(buyerName);
	}
	
	}
