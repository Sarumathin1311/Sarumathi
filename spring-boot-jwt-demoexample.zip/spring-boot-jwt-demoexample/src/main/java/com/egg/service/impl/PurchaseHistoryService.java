package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.PurchaseDao;
import com.egg.model.PurchaseHistoryEntity;



@Service
public class PurchaseHistoryService {

	
	

	@Autowired
	private  PurchaseDao purchaseDao;
	
	
	
	
	public List<PurchaseHistoryEntity> getAllPurchaseItems(Integer buyerId){
		return purchaseDao.getallPurchaseitems(buyerId);
	}
}
