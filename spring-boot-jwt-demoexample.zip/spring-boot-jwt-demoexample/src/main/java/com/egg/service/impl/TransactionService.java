package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.TransactionDao;
import com.egg.model.TransactionEntity;


@Service
public class TransactionService {

	
	@Autowired
	private TransactionDao transactionDao;
	
	public List<TransactionEntity> getAllTransactionItems(Integer buyerId){
		return transactionDao.getallTransactionitems(buyerId);
	}
}
