package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.PurchaseHistoryEntity;




@Repository
public interface PurchaseDao extends JpaRepository<PurchaseHistoryEntity, Integer> {

	@Query(value = "SELECT * FROM purchase_history_entity c WHERE c.buyer_id = :buyerId"
			,nativeQuery = true)
	public List<PurchaseHistoryEntity> getallPurchaseitems(@Param("buyerId")Integer buyerId);
}
