
package com.egg.model;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class BuyerEntity {
	@Id
	@GeneratedValue
	private int buyerId;
	private String buyerName;
	private String buyerPass;
	private String buyerEmail;
	private String buyerMobile;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate createdate;
	
	
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public String getBuyerPass() {
		return buyerPass;
	}
	public void setBuyerPass(String buyerPass) {
		this.buyerPass = buyerPass;
	}
	public String getBuyerEmail() {
		return buyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}
	public String getBuyerMobile() {
		return buyerMobile;
	}
	public void setBuyerMobile(String buyerMobile) {
		this.buyerMobile = buyerMobile;
	}
	public LocalDate getCreatedate() {
		return createdate;
	}
	public void setCreatedate(LocalDate createdate) {
		this.createdate = createdate;
	}
	
	public BuyerEntity(int buyerId, String buyerName, String buyerPass, String buyerEmail, String buyerMobile,
			LocalDate createdate) {
		super();
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.buyerPass = buyerPass;
		this.buyerEmail = buyerEmail;
		this.buyerMobile = buyerMobile;
		this.createdate = createdate;
	}
	public BuyerEntity() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BuyerEntity [buyerId=" + buyerId + ", buyerName=" + buyerName + ", buyerPass=" + buyerPass
				+ ", buyerEmail=" + buyerEmail + ", buyerMobile=" + buyerMobile + ", createdate=" + createdate + "]";
	}
	

	/*@OneToMany(mappedBy="BuyerEntity", cascade=CascadeType.ALL)
	private List<PurchaseHistoryEntity> purchasehistory;*/
	
	/*@OneToMany(targetEntity=ShoppingCartEntity.class, cascade=CascadeType.ALL)
	private List<ShoppingCartEntity> Shoppingcartt;*/
	
	
	

	
	
	
	
}