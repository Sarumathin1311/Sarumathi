package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.PurchaseHistoryEntity;
import com.egg.service.impl.PurchaseHistoryService;

@RestController
@RequestMapping("/purchase")
@CrossOrigin(origins="*")
public class PurchaseHistoryController {
	
	@Autowired
	private PurchaseHistoryService purchasehistoryService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<PurchaseHistoryEntity> getAllPurchaseItems(@PathVariable("bid")Integer buyerId) {
	return purchasehistoryService.getAllPurchaseItems(buyerId);
	
	}
}

