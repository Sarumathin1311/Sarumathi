
package com.egg.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ShoppingCartEntity;
import com.egg.model.TransactionEntity;
import com.egg.service.impl.ShoppingCartService;


@RestController
@RequestMapping("/cart")
@CrossOrigin(origins="*")
public class ShoppingCartController {
	
	@Autowired
	private ShoppingCartService shoppingcartService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<ShoppingCartEntity> getAllCartItems(@PathVariable("bid")Integer buyerId) {
	return shoppingcartService.getAllCartItems(buyerId);
	
	}

	
	@PostMapping(value="/{bid}/add",produces = "application/json")
	public ShoppingCartEntity addCartItem(@PathVariable("bid") Integer buyerId,@RequestBody ShoppingCartEntity shoppingCartItem) {
		Optional<ShoppingCartEntity> savedItem = shoppingcartService.addCartItem(shoppingCartItem, buyerId);
		return savedItem.get();
	}
	
	@DeleteMapping(value = "/{cartid}/deletebyid")
	public String deleteCartItem(@PathVariable("cartid") Integer Id) {
		return shoppingcartService.deleteCartItemById(Id);
	}
	
	@DeleteMapping(value = "/{bid}/deleteall")
	public void emptyCart(@PathVariable("bid") Integer buyerId) {
		shoppingcartService.emptyCart(buyerId);
	}
	
	@PutMapping(value = "/{cartid}/update",produces = "application/json")
	public ShoppingCartEntity updateCart(@RequestBody ShoppingCartEntity shoppingCartItem,@PathVariable("cartid") Integer Id) {
		return shoppingcartService.updateCart(shoppingCartItem, Id);
	}
	@PostMapping(value="/{bid}/checkout",produces = "application/json")
	public String checkOut(@RequestBody TransactionEntity transaction,@PathVariable("bid")int buyerid)
	{
		return shoppingcartService.checkOut(transaction, buyerid);
		
	}

}
