export class BuyerEntity {

buyerName:String;
 buyerPass:String;
 buyerEmail:String;
 buyerMobile:number;

   
   
   
   }