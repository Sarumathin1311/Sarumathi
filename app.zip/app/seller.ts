export class SellerEntity {
	sellerName:String;
	 sellerPass:String;
	 sellercmyName:String;
	 cmyDescription:String;
sellerAddress:String;
	sellerWebsite:String;
   sellerEmail:String;
    sellerMobile:String;
 
       
       
       
       }