import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { TransactionEntity } from '../transaction';
import { shoppingcart } from '../cart';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  constructor(private displaycart:ProductService) { }
  transaction:TransactionEntity;
  transactionType:String;

  cart:shoppingcart=new shoppingcart();
  
  ngOnInit(): void {
  }
  Checkout(){
    console.log();
    this.transaction=new TransactionEntity();
    this.transaction.transactionType=this.transactionType;
   
   this.displaycart.CheckoutCart(this.transaction).subscribe(view => this.transaction=view);
   }
}
