export class PurchaseHistoryEntity{

    purchasehisId:number;
    numberofItems:number;
    itemName:String;
    itemPrice:number;

   
}
