export class TransactionEntity{

    transactionId:number;
    transactionType:String;
    transactionDate:Date;
    
   
}
