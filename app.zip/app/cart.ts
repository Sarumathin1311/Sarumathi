export class shoppingcart {

 cartId:number;
    itemId:number;
    itemName:String;
 itemQuantity:number;
 itemPrice:number;
 itemDescription:String;
totalPrice:number;



}