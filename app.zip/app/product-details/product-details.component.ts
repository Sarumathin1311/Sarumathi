import { Component, OnInit, Input } from '@angular/core';
import {ItemEntity } from '../items';
import { from } from 'rxjs';
import { ProductService } from '../product.service';
import {shoppingcart } from '../cart';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 
  @Input() 
  item :ItemEntity;
  product:any;
  cart:shoppingcart = new shoppingcart();
  constructor(private PService : ProductService ) { }
  
  ngOnInit(): void {
  }

  onSave(itemId : number){
    
 this.cart.itemId=this.item.itemId;
 this.cart.itemName=this.item.itemName;
 this.cart.itemDescription=this.item.description;
 this.cart.itemQuantity=this.item.stockNumber;
 this.cart.itemPrice=this.item.itemPrice;
    this.PService.addToCart(this.cart).subscribe(product=>{this.product=product;},
      error => console.log('erorr'+error));
  }

  

}
