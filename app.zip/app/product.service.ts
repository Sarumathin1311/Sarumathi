import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { shoppingcart } from './cart';
import { TransactionEntity } from './transaction';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8999';



  constructor(private http: HttpClient) { }

  getItems(itemName: string) : Observable<any> {
    console.log(itemName);

    return this.http.get(`http://localhost:8998/items/searchbyname/${itemName}`);
  }
  addToCart(cart:shoppingcart):Observable<any> {
return this.http.post(`http://localhost:8999/cart/1/add`,cart);


  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8999/cart/1/getAll`);

}


addbuyer(BuyerEntity:object):Observable<any>
{ 
  
console.log("in last ts");
console.log(BuyerEntity);
  return this.http.post(`${this.baseUrl}/buyer/add`,BuyerEntity);
}

updateCartItems(cart:shoppingcart,cartId:number,):Observable<any>{
  return this.http.put(`${this.baseUrl}/cart/${cartId}/update`,cart);
}

deletecartItems(cartId:number)
{
  return this.http.delete(`${this.baseUrl}/cart/${cartId}/deletebyid`,);
}

emptyCart()
{
  return this.http.delete(`${this.baseUrl}/cart/2/deleteall`,);
}


displaypurchaseItems() :Observable<any>
{
  return this.http.get(`http://localhost:8999/purchase/1/getAll`);
}

CheckoutCart(transaction:TransactionEntity): Observable<any> {
  
  return this.http.post(`http://localhost:8999/cart/1/checkout`,transaction);
  window.alert("checkout done successfully");
}


displaytransactionItems() :Observable<any>
{
  return this.http.get(`http://localhost:8999/transaction/1/getAll`);
}


}


