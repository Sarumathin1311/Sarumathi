import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { PurchaseHistoryEntity } from '../purchase';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchasehistoryComponent implements OnInit {

  phistory:PurchaseHistoryEntity[];
  constructor(private pservice:ProductService) { }

  ngOnInit(): void {
    this.pservice.displaypurchaseItems().subscribe( phistory => this.phistory=phistory)
    console.log(this.phistory);
  }

}
