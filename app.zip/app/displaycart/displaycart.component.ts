import { Component, OnInit } from '@angular/core';
import { shoppingcart } from '../cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  disCart:shoppingcart[];
  TotalPrice:number;
  
  constructor(private displaycart:ProductService) { }

  ngOnInit(): void {


    this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
  }

  decrement(cart:shoppingcart,cartId:number)
  {
    this.TotalPrice=cart.itemPrice;
    console.log(cart.itemPrice);
    if(cart.itemQuantity!=1){
      cart.itemQuantity-=1;
      cart.totalPrice= cart.itemQuantity * this.TotalPrice;
      console.log(cart.itemQuantity,cart.cartId);
      
      this.displaycart.updateCartItems(cart,cartId).subscribe(newview => this.disCart=newview);
      }

  }

  
  increment(cart:shoppingcart,cartId:number)
  {
    this.TotalPrice=cart.itemPrice;
    cart.itemQuantity= cart.itemQuantity+1;
    if(cart.itemQuantity!=1){
  
      cart.totalPrice= cart.itemQuantity * this.TotalPrice;
      console.log(cart);
      console.log("Quantity"+cart.itemQuantity+"\ncartId"+cart.cartId);
      
      this.displaycart.updateCartItems(cart,cartId).subscribe(newview => this.disCart=newview);
      }

  }


  DeleteItem(i){

    console.log("method invoked");
    console.log(i);
    this.displaycart.deletecartItems(i).subscribe(

      () =>{console.log("deleted Item"); this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);}, (error) => console.log(error)

    );
  }

  DeleteAll(){
    this.displaycart.emptyCart().subscribe(
    () =>console.log("Delete All Items"),
    (error) =>console.log(error));

  }


}
