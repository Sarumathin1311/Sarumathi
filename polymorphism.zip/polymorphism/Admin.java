package com.cts.polymorphism;

public class Admin extends Employee{
	public void adminMethod() {
		System.out.println("Admin");
	}
	public void employeeMethod() {
		System.out.println("Employee-Admin");
	}
}
