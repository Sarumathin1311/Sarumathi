package com.cts.polymorphism;

public class TestPolymorphism {

	public static void main(String[] args) {
		Employee e = null;
		e = new Employee();
		e.employeeMethod();
		
		e = new Admin();//Upward casting Done by compiler
		//it should be used when you want to use override method of base class which is employee method.
		e.employeeMethod();
		
		Admin ad = (Admin)e;//Downward Casting To use the featured method of Admin class.
		ad.adminMethod();
		
		e = new Manager();//upward casting
		e.employeeMethod();
		
		Manager mg = (Manager)e;//Downward Casting
		mg.managerMethod();
		
		if(e instanceof Manager) {
			mg = (Manager)e;
			mg.managerMethod();
		}
		else {
			if(e instanceof Admin) {
				ad = (Admin)e;
				ad.adminMethod();
			}
			else {
				e.employeeMethod();
			}
		}
	}
}
