package com.cts.polymorphism;

public class Manager extends Employee{
	public void managerMethod() {
		System.out.println("Manager");
	}
	public void employeeMethod() {
		System.out.println("Employee-Manager");
	}
}
